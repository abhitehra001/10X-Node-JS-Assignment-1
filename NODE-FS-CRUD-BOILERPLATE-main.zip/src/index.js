const fs = require('fs/promises')

const myFileWriter = async (fileName, fileContent) => {
	// write code here
	// dont chnage function name
    fs.writeFile(`${fileName}.txt`, `${fileContent}`, (err)=>{
        console.log("Error occured in myFileWriter:", err);
    })
}

const myFileReader = async (fileName) => {
	// write code here
	// dont chnage function name
    const data = await fs.readFile(`${fileName}.txt`, "utf8", (err, data) => {
		if(err){
			return `Error occured in myFileReader: ${err}`;
		}else{
			return data;
		}
	})
	console.log(data);
}


const myFileUpdater = async (fileName, fileContent) => {
	// write code here
	// dont chnage function name
	fs.appendFile(`${fileName}.txt`, `${fileContent}`, (err) => {
		if(err){
			console.log("Error occured in myFileUpdater:", err);
		}
	})
}

const myFileDeleter = async (fileName) => {
	// write code here
	// dont chnage function name
	fs.unlink(`${fileName}.txt`, (err) => {
		console.log("Error occured in myFileDeleter:", err);
	})
}



module.exports = { myFileWriter, myFileUpdater, myFileReader, myFileDeleter }