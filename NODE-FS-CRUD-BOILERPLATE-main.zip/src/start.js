const read = require("./index.js");

read.myFileReader("printName");